//
//  DayConfig.swift
//  AlaahNames_WidgetExtension
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import Foundation
import SwiftUI

struct DayConfig{
    let name: String
    let desc: String
    
    static func determineConfig(from date: Date) -> DayConfig{
        let dayInt = Calendar.current.component(.day, from: date)
        
        switch dayInt {
        case 1:
          return  DayConfig(name: "اللطيف", desc: "يسوق لك الخير وأنت لاتشعر")
        case 2:
            return DayConfig(name: "الرحمن", desc: "الرفيق بمن أحبَّ أن يرحمه")
        default :
         return   DayConfig(name: "الخبير", desc: "زكي نفسك فالله يعلم حالك")
//        default:
//            return DayConfig(name: "أسماء الله الحسنى", desc: "..")
        }
    }
}

