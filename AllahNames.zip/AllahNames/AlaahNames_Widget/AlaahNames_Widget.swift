//
//  AlaahNames_Widget.swift
//  AlaahNames_Widget
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import WidgetKit
import SwiftUI
import Intents

struct Provider: IntentTimelineProvider {
    func placeholder(in context: Context) -> DayEntry {
        DayEntry(date: Date(), configuration: ConfigurationIntent())
    }

    func getSnapshot(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (DayEntry) -> ()) {
        let entry = DayEntry(date: Date(), configuration: configuration)
        completion(entry)
    }

    // entries = data , updates data
        func getTimeline(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
            var entries: [DayEntry] = []

            // Generate a timeline consisting of 7 entries an day apart, starting from the current date.
            let currentDate = Date()
            for dayOffset in 0 ..< 7 {
                let entryDate = Calendar.current.date(byAdding: .day, value: dayOffset, to: currentDate)!
                let startDay = Calendar.current.startOfDay(for: entryDate)
                let entry = DayEntry(date: startDay, configuration: configuration)
                entries.append(entry)
            }

            let timeline = Timeline(entries: entries, policy: .atEnd)
            completion(timeline)
        }
}

struct DayEntry: TimelineEntry {
    let date: Date
    let configuration: ConfigurationIntent
}

struct AlaahNames_WidgetEntryView : View {
    var entry: DayEntry
    var config: DayConfig

    init(entry: DayEntry) {
        self.entry = entry
        self.config = DayConfig.determineConfig(from: entry.date)
    }
    var body: some View {
        ZStack{
//            ContainerRelativeShape()
//                .fill(.white.gradient)
            Image("homebg")
                .resizable()
            VStack(alignment: .center){
                Text(config.name)
                    .font(.title)
                    .bold()
                    .padding()
                Text(config.desc)
                    .multilineTextAlignment(.center)
                
                Text(entry.date.weekdayDisplayFormat)
                    .font(.footnote)
//                Text(entry.date.formatted(.dateTime.day()))
            }
          
            
        }
    }
}

struct AlaahNames_Widget: Widget {
    let kind: String = "AlaahNames_Widget"

    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: ConfigurationIntent.self, provider: Provider()) { entry in
            AlaahNames_WidgetEntryView(entry: entry)
        }
        .configurationDisplayName("Name Of Allah")
        .description("كل يوم اسم ومعنى")
      //  .supportedFamilies([.systemSmall, .systemMedium])
    }
}

struct AlaahNames_Widget_Previews: PreviewProvider {
    static var previews: some View {
        AlaahNames_WidgetEntryView(entry: DayEntry(date: dateToDisplay(day: 3), configuration: ConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemSmall))
    }
    
    static func dateToDisplay(day: Int) -> Date{
        let component = DateComponents(calendar: Calendar.current,
                                       year: 2023,
                                       month: 3,
                                       day: day)
        return Calendar.current.date(from: component)!
    }
}

extension Date {
    var weekdayDisplayFormat: String {
        self.formatted(.dateTime.weekday(.wide))
    }
}
