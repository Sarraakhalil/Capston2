//
//  AlaahNames_WidgetBundle.swift
//  AlaahNames_Widget
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import WidgetKit
import SwiftUI

@main
struct AlaahNames_WidgetBundle: WidgetBundle {
    var body: some Widget {
        AlaahNames_Widget()
        AlaahNames_WidgetLiveActivity()
    }
}
