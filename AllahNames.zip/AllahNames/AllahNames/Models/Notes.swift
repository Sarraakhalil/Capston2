//
//  Notes.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import Foundation

struct NoteModel: Identifiable {
    let id: String = UUID().uuidString
    let title: String
    let note: String 
    //let isCompleted: Bool
}


