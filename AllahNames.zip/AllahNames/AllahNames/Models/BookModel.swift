//
//  BookModel.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import Foundation

struct Books {
    let id = UUID()
    let image : String
    let name : String
    let bookstore : String
    let rate: String
    
    
    static var booksList = [
    Books(image: "book1", name: "لأنك الله", bookstore: "مكتبة جرير", rate: "٩.٨"),
    Books(image: "book3", name: "٣٠ يوما مع الله ", bookstore: "متجر ألسن", rate: "٩.٢"),
    Books(image: "book4", name: " رسائل من الله", bookstore: "دار طيبة للنشر والتوزيع ", rate: "٨.٨"),
    Books(image: "book2", name: " أسماء الله الحسنى", bookstore: "مكتبة الرشد", rate: "٨.٥"),
  
    ]
}
