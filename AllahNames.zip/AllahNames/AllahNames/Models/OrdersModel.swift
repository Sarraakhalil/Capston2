//
//  OrdersModel.swift
//  AllahNames
//
//  Created by سرّاء. on 21/07/1444 AH.
//

import Foundation

struct Orders: Identifiable {
    let id: String = UUID().uuidString
    let name: String
    let author: String
    let quantity: String
        
}
