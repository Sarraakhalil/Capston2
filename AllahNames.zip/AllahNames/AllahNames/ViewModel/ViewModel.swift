//
//  ViewModel.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import Foundation
import SwiftUI

struct Names: Codable, Hashable{
    let name: String
    let text: String
}

func parseJSON() async {
    guard let url = URL(string: "file:///Users/sarraa/Downloads/Names_Of_Allah_Json-main/Names_Of_Allah.json") else { print("URL Does NOT Work!!!")
        return}


    do {
        let jsinDecoder = JSONDecoder()
        let (data, _) = try await URLSession.shared.data(from: url)
        let user = try jsinDecoder.decode([Names].self, from: data)
    }
    catch{
        print("Data Valid!!!")
    }
}
