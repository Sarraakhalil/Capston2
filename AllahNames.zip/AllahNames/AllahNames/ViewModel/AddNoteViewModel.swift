//
//  AddNoteViewModel.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import Foundation

class ListViewModel: ObservableObject {
    @Published var items: [NoteModel] = []
    
    init() {
        getItems()
    }
    
    func getItems() {
        let newItem = [
            NoteModel(title: "الودود", note: "محبته في قلوب خواص خلقه، لايشبهها شيء من أنواع المحاب"),
            NoteModel(title: "اللطيف", note: "من معاني اللطيف أنه الذي يلطف بعبده فيسوق إليه البر والإحسان من حيث لا يشعر.")
        ]
        items.append(contentsOf: newItem)
    }
    
    func deletItem(indexSet: IndexSet) {
        items.remove(atOffsets: indexSet)
    }
    func moveItem(from: IndexSet, to: Int){
        items.move(fromOffsets: from, toOffset: to)
    }
    func addItem(title: String, note: String) {
        let newItem = NoteModel(title: title, note: note)
        //ItemModel(title: title, isCompleted: false)
        items.append(newItem)
    }
    
}
