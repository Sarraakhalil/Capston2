//
//  OrdersViewModel.swift
//  AllahNames
//
//  Created by سرّاء. on 21/07/1444 AH.
//

import Foundation
import FirebaseFirestore

class OrdersViewModel: ObservableObject {

    @Published var orders = [Orders]()

    private var db = Firestore.firestore()

    func fetchData() {
        db.collection("Books").addSnapshotListener { (querySnapshot, error) in
            guard let documents = querySnapshot?.documents else {
                print("No documents")
                return
            }

            self.orders = documents.map { (queryDocumentSnapshot) -> Orders in
                let data = queryDocumentSnapshot.data()
                let name = data["name"] as? String ?? ""
                let author = data["author"] as? String ?? ""
                let quantity = data["quantity"] as? String ?? ""
                return Orders(name: name , author: author, quantity: quantity)
            }
        }
    }
}
