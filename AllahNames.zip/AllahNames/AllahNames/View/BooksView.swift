//
//  BooksView.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI

struct BooksView: View {
    let booklist = Books.booksList
    var fav: Bool = false
    var body: some View {
        NavigationStack{
            List{
                ForEach(booklist, id: \.id) { book in
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.gray.opacity(0.1)).ignoresSafeArea()
                        .frame(width: 320, height: 140)
                        .shadow(radius: 8).padding()
                        .overlay(){
                           NavigationLink(destination: {BookDescription()}, label: {
                               ZStack(alignment: .topLeading) {
                                   HStack{
                                       Image(book.image)
                                           .resizable()
                                           .frame(width: 120, height: 140)
                                           .cornerRadius(16)
                                           .padding(.bottom, 30)
                                           .padding(.trailing)
                                       VStack{
                                           HStack{
                                               Text(book.name)
                                               Spacer()
                                               Image(systemName: "star.fill")
                                                   .foregroundColor(Color.yellow)
                                                   .font(.footnote)
                                               Text(book.rate)
                                                   .foregroundColor(Color.orange)
                                                   .bold()
                                             
                                           }
                                           HStack{
                                               Text(book.bookstore)
                                               Spacer()
                                               Image(systemName: fav ? "heart.fill" : "heart")
                                                   .foregroundColor(.red)
                                               
                                               
                                           }
                                       }
                                   }
                               }.frame(width: 300)
                         .foregroundColor(.black)
                           })
                                
                        
                        }
                }
            }
            .navigationTitle("الكتب")
        
        }
    }
}

struct BooksView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            BooksView()
        }
    }
}
