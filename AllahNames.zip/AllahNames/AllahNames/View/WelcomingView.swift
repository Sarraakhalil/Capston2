//
//  WelcomingView.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI

struct WelcomingView: View {
    var body: some View {
            ZStack{
                Image("welcomingbg2")
                    .resizable()
                    .ignoresSafeArea()
                VStack{
                        Text("مرحبا بك في تطبيق")
                            .font(.title2)
                            .bold()
                            .padding()
                            .padding(.top, 90)
                        Text("")
                            .font(.largeTitle)
                            .bold()
                            .padding()
                        Spacer()
                        Text(" تعرف على أسماء الله الحسنى ومعانيها بكل سهولة")
                            .font(.title3)
                            .multilineTextAlignment(.center)
                            .padding()
                    
                  Spacer()
                   
                     Text("انضم معنا الآن")
                         .font(.title3)
                         .padding()
                    HStack{
                         
                        NavigationLink(destination: {RegisterView()}, label: {
                            Text("تسجيل جديد")
                                .foregroundColor(.black)
                                .frame(width: 160, height: 50)
                                .background(.white)
                                .cornerRadius(24)
                        })
                        
                        NavigationLink(destination: {LogInView()}, label: {
                            Text("تسجيل دخول")
                                .foregroundColor(.black)
                                .frame(width: 160, height: 50)
                                .background(.white)
                                .cornerRadius(24)
                        })   .navigationBarBackButtonHidden(true)
                       
                      }.padding(.bottom, 40)
                }
            }
             
    }
}

struct WelcomingView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            WelcomingView()
        }
    }
}
