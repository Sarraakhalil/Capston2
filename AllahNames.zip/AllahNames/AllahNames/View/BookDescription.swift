//
//  BookDescription.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI
import FirebaseFirestore
struct BookDescription: View {
    let db = Firestore.firestore()
    var body: some View {
        VStack{
            VStack{
                Image("book3")
                    .resizable()
                    .frame(width: 400, height: 500)
                   // .ignoresSafeArea()
            }
            
            VStack {
                VStack(alignment: .leading){
                    HStack{
                        Text("اسم الكتاب: ")
                        Text("لأنك الله")
                    }
                    HStack{
                        Text("اسم المؤلف: ")
                        Text("فيصل بخاري ")
                    }
                    HStack{
                        Text("اسم المكتبة : ")
                        Text("متجر ألسن ")
                    }
                    HStack{
                        VStack(alignment: .leading){
                            Text("وصف الكتاب  : ")
                            Text("كيف هي علاقتنا مع الله ؟ \n عندما تدمرنا الحياة وتنضغط إلى أن نفقد آمالنا بأنفسنا إلى من تلتجئ ؟\n  هل تلتجئ إلى الخالق؟ أم تلتجئ إلى الصديق الذي ليس بيده شيء؟ أم تلتجئ للمحرمات!\n  هل أنت ممن يعلق قلبه بالله في جميع أمور حياته؟ أم أنت الناسي ولا تعود إليه إلا في حاجتك للإله جل جلاله!  ")
                        }
                    }
               
                }
            

                
                Button(action: {
                   db.collection("Books")
                        .document("book1")
                        .setData([
                            "Name": " ٣٠ يوما مع الله",
                            "Author": "فيصل بخاري",
                            "quantity" : "1"
                           ]
                        ){error in
                            guard error != nil else {
                                print("Succes")
                                return }
                                             }
                }, label: {
                    Text("إضافة")
                }).frame(width: 200, height: 40)
                    .background(Color("green2"))
                    .cornerRadius(16)
                    .foregroundColor(.black)
                    .bold()
                 
                HStack{
                    Button(action: {
                 updateData(quantity: "2", books: "book1")
                    }, label: {
                        Text("تعديل الكمية")
                    }).frame(width: 160, height: 40)
                        .background(Color("green2"))
                        .cornerRadius(16)
                        .foregroundColor(.black)
                        .bold()
                        .padding()
                    
                    
                    
                    
                    Button(action: {
                        db.collection("Books").document("book1").delete() { err in
                            if let err = err {
                                print("Error Delete document: \(err)")
                            } else {
                                print("Document successfully Delete")
                            }
                        }
                    }, label: {
                        Text("حذف")
                    }).frame(width: 160, height: 40)
                        .background(Color("green2"))
                        .cornerRadius(16)
                        .foregroundColor(.black)
                        .bold()
                }
            }
            .padding()
            .frame(width: 400, height: 400)
                .background(.white)
            .padding(.top, -260)
              
        }
    }
    
    func updateData(quantity: String, books: String) {
          db.document(books).updateData(["quantity" :quantity ]) { error in
              if let error = error {
                  print(error.localizedDescription)
              } else {
                  print("Note updated succesfully")
              }
          }
      }
    
}

struct BookDescription_Previews: PreviewProvider {
    static var previews: some View {
        BookDescription()
    }
}
