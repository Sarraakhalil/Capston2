//
//  LocationView.swift
//  AllahNames
//
//  Created by سرّاء. on 20/07/1444 AH.
//

import SwiftUI
import MapKit
import CoreLocationUI
struct LocationView: View {
    
@StateObject private var locationvm = LocationViewModel()
    
    var body: some View {
        ZStack(alignment:.bottom) {
            Map(coordinateRegion: $locationvm.region, showsUserLocation: true)
             
      //  .ignoresSafeArea ()
        .tint(.pink)
            
            LocationButton (.currentLocation) {
                locationvm.requestAllowOnceLocationPermission()
            }
                .foregroundColor(.white)
                .cornerRadius(8)
                .labelStyle(.titleAndIcon)
                .symbolVariant(.fill)
                .tint (.pink)
                .padding (.bottom, 50)
        }
    }
}

struct LocationView_Previews: PreviewProvider {
    static var previews: some View {
        LocationView()
    }
}

final class LocationViewModel: NSObject, ObservableObject, CLLocationManagerDelegate{
    @Published  var region = MKCoordinateRegion (center: CLLocationCoordinate2D(latitude: 30,
    longitude: 50), span: MKCoordinateSpan(latitudeDelta: 30, longitudeDelta:30))
    
    let locationManger = CLLocationManager()
    
    override init() {
        super.init()
        locationManger.delegate = self
    }
    
    func requestAllowOnceLocationPermission() {
        locationManger.requestLocation()
    }
    
    func locationManager (_ manager: CLLocationManager, didUpdateLocations locations:
                          [CLLocation]){
        guard let latestLocation = locations.first else {
            // show an error
            return
        }
        DispatchQueue.main.async {
            self.region = MKCoordinateRegion (center: latestLocation.coordinate, span:
        MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
        }
    }
    
    func locationManager (_ manager: CLLocationManager, didFailwithError error: Error) {
    print(error.localizedDescription)
    }
    
    
    
    
}
