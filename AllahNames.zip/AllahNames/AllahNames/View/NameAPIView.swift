//
//  NameAPIView.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI


struct NameAPIView: View {
    @State var names = [Names]()
    var body: some View {
        NavigationStack{
            List(names, id: \.self) { name in
                HStack{
                    Text(name.name)
                        .font(.title2)
                        .bold()
                        .foregroundColor(Color("green1"))
                    Text(name.text)
                        .listRowSeparatorTint(.green)
                }
            }.listStyle(.sidebar)
            
        }
        .navigationTitle("أسماء الله الحسنى")
        .task {
            await
            fetchData()
            //parseJSON()
        }
    }
    
    func fetchData() async {
        //create url
        guard let url = URL(string: "file:///Users/sarraa/Downloads/Names_Of_Allah_Json-main/Names_Of_Allah.json")
        else {
           return print("URL Does NOT Work!!!")
        }
        //fetch data from that url
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            //decode that data
            if let decodedResponse = try? JSONDecoder().decode([Names].self, from: data) {
            names = decodedResponse
            }
        }
        catch {
            print("Data valid")
        }
    }
    
    
    
    
    
}

struct NameAPIView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            NameAPIView()
        }
    }
}
