//
//  AddNoteList.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI

struct AddNoteList: View {
    let item: NoteModel
    var body: some View {
        VStack(alignment: .leading){
            Text(item.title)
                .bold()
                .foregroundColor(Color("green1"))
                .font(.title2)
            Text(item.note)
                .font(.title3)
                .foregroundColor(.secondary)
          //  Spacer()
        }
       
      //  .padding(.vertical, 8)
    }
}

struct AddNoteList_Previews: PreviewProvider {
    static var item1 = NoteModel(title: "فائدة١", note: "تجربة الفائدة الأولى")
    static var previews: some View {
        AddNoteList(item: item1)
    }
}
