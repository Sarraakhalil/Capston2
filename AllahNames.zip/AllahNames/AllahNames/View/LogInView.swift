//
//  LogInView.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI
import FirebaseAuth

struct LogInView: View {
    @State var email: String = ""
    @State var pass: String = ""
    var body: some View {
        ZStack{
            Image("loginbg")
                .resizable()
                .frame(width: 600, height: 1000)
                .padding(.leading, -100)
            VStack{
                Text("تسجيل الدخول")
                    .font(.title)
                    .bold()
                    .padding(.bottom, 40)
                VStack{
                    HStack{
                        Image(systemName: "envelope")
                        TextField("الايميل", text: $email)
                            .padding()
                            .frame(width: 240, height: 50)
                        
                    }  .frame(width: 320, height: 60)
                        .background(.white)
                        .shadow(radius: 2)
                        .cornerRadius(40)
                        .padding(.leading, -120)
                        .padding(.bottom, 20)
                    
                    HStack{
                        Image(systemName: "lock")
                        SecureField("الرمز السري", text: $pass)
                            .padding()
                            .frame(width: 240, height: 50)
                        
                    }  .frame(width: 320, height: 60)
                        .background(.white)
                        .shadow(radius: 2)
                        .cornerRadius(40)
                        .padding(.leading, -120)
                        .padding(.top, 10)
                     
                    Button(action: {SignIn()}, label: {
                        Text("تسجيل الدخول")
                            .foregroundColor(.black)
                              .bold()
                              .font(.title3)
                              .frame(width: 310, height: 50)
                              .background(.white.opacity(0.9))
                              .cornerRadius(40)
                              .shadow(radius: 2)
                              .padding(.leading, -50)
                              .padding()
                    }).padding(.top, 40)
                    
                    HStack{
                        Text("لا تملك حساب؟ ")
                            .font(.title3)
                        NavigationLink(destination: {RegisterView()}, label: {
                            Text("سجل الآن")
                        })
                        
                    }  .padding(.top, 80)
                }
            }
        }
        
    }

//    func SignIn1() {
//        Auth.auth().signIn(withEmail: email, password: pass){result, error in
//            if error == nil {
//            //
//            } else{
//                print("error")
//            }
//
//        }
//    }
    
  
    func SignIn() {
        Auth.auth().signIn(withEmail: email, password: pass){result, error in
            if error != nil {
                print(error?.localizedDescription ?? "")
            } else{
                print("Log in")
            }

        }
    }

    
}

struct LogInView_Previews: PreviewProvider {
    static var previews: some View {
        LogInView()
    }
}


