//
//  AddNoteView.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI

struct AddNoteView: View {
    @Environment(\.presentationMode) var peresentationMode
    @EnvironmentObject var listViewModel: ListViewModel
    @State var textFieldtitle: String = ""
    @State var textFieldnote: String = ""
    var body: some View {
        ScrollView{
            VStack(alignment: .leading){
                VStack{
                    TextField("عنوان الفائدة ", text: $textFieldtitle)
                        .padding(.horizontal)
                        .frame(height: 55)
                        .background(Color("green3"))
                        .cornerRadius(10)
                        .padding()
                    Spacer()
                    TextField("اكتب فائدتك ", text: $textFieldnote)
                        .padding(.horizontal)
                        .frame(width: 360, height: 300)
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(10)
                        .padding(.bottom, 40)
                }
            
                VStack{
                    Button(action: {saveButtonPressed()}, label: {
                        Text("حفظ")
                            .foregroundColor(.white)
                            .frame(height: 55)
                            .frame(maxWidth: .infinity)
                            .background(Color("green1"))
                            .cornerRadius(10)
                    })
                }
             
                
            }
            .padding()
        }
        .navigationTitle("الفوائد")
        
    }
    
    
    
    func saveButtonPressed() {
        listViewModel.addItem(title: textFieldtitle, note: textFieldnote)
        peresentationMode.wrappedValue.dismiss()
    }
    
}

struct AddNoteView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            AddNoteView()
        }  .environmentObject(ListViewModel())
    }
}
