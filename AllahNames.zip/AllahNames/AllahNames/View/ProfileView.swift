//
//  ProfileView.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI
import FirebaseAuth
struct ProfileView: View {
    var body: some View {
        ZStack{
           Image("homebg")
                .resizable()
                .ignoresSafeArea()
            
            
            VStack {
                VStack{
                    ZStack{
                        Circle()
                            .fill(Color("green2"))
                            .frame(width: 160, height: 200)
                        
                        Image(systemName: "person")
                            .resizable()
                            .frame(width: 80, height: 80)
                        
                            .padding()
                        
                    }.padding(.top, 40)
                    Text("سرّاء المديفر")
                        .font(.title2)
                        .bold()
                        .padding(.bottom)
                  
                }
                Spacer()
                VStack{
                    Buttons()
                }
               
            }
        }
    }
    
   
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            ProfileView()
        }
    }
}



struct Buttons: View {
    var body: some View {
        VStack {
            ZStack(alignment: .trailing) {
                HStack{
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color("green2")).ignoresSafeArea()
                        .frame(width: 80, height: 80)
                        .shadow(radius: 8).padding()
                        .overlay{
                            Image(systemName: "person")
                        }//.padding(.trailing, 100)
                    VStack{
                        HStack{
                            Text("الملف الشخصي")
                        }
                    }
                }.frame(width: 300, height: 60)
                    .background(Color("green1"))
                
            }.padding()
            
            NavigationLink(destination: {ReadOrdersView()}, label: {
                
                ZStack(alignment: .trailing) {
                    HStack{
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color("green2")).ignoresSafeArea()
                            .frame(width: 80, height: 80)
                            .shadow(radius: 8).padding()
                            .overlay{
                                Image(systemName: "gear.circle")
                            }
                            .padding(.trailing, 30)
                        VStack{
                            HStack{
                                
                                Text("طلباتي")
                            }
                        }
                    }.frame(width: 300, height: 60)
                        .background(Color("green1"))
                    
                }.padding()
            }).foregroundColor(.black)
          
            
            
            
            Button(action: {SignOut()}, label: {
             ZStack(alignment: .trailing) {
                 HStack{
                     RoundedRectangle(cornerRadius: 12)
                         .fill(Color("green2")).ignoresSafeArea()
                         .frame(width: 80, height: 80)
                         .shadow(radius: 8).padding()
                         .overlay{
                             Image(systemName: "rectangle.portrait.and.arrow.forward")
                         }
                         //.padding(.trailing, 100)
                     VStack{
                         HStack{
                             Text("تسجيل خروج")
                         }
                     }
                 }.frame(width: 300, height: 60)
                     .background(Color("green1"))
                 
             }.padding()
         }).foregroundColor(.black)

        }            .frame(width: 400, height: 500)
            .background(Color.white)

    }
    
    func SignOut() {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print("Error signing out:", signOutError)
        }
        print("Log Out")
    }
}
