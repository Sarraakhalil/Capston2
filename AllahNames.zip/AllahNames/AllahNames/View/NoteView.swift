//
//  NoteView.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI


struct NoteView: View {
    @EnvironmentObject var addNoteVM : ListViewModel
    var body: some View {
        List{
            ForEach(addNoteVM.items){ item in
                AddNoteList(item: item)
            }
            .onDelete(perform:addNoteVM.deletItem)
            .onMove(perform:addNoteVM.moveItem)
        }
        .listStyle(PlainListStyle())
        .navigationTitle("الفوائد")
        .navigationBarItems(
            leading: EditButton(),
            trailing:
        NavigationLink("إضافة", destination: AddNoteView()))
    }
}

struct NoteView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            NoteView()
        }
        .environmentObject(ListViewModel())
    }
}
