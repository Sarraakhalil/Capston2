//
//  ReadOrdersView.swift
//  AllahNames
//
//  Created by سرّاء. on 21/07/1444 AH.
//

import SwiftUI

struct ReadOrdersView: View {
    @ObservedObject private var order = OrdersViewModel()
    var body: some View {
        NavigationView {
            VStack{
                List(order.orders) { order in
                VStack(alignment: .leading){
                    HStack{
                        Text("اسم الكتاب:")
                            .foregroundColor(Color("green1"))
                            .bold()
                        Text(order.name)
                         
                    }
                    HStack{
                        Text("اسم الكاتب:")
                            .foregroundColor(Color("green1"))
                            .bold()
                        Text(order.author)
                    }
                    HStack{
                        Text("الكمية:")
                            .foregroundColor(Color("green1"))
                            .bold()
                        Text(order.quantity)
                            
                    }
                }
            }  .onAppear(){
                self.order.fetchData()
            }
            
            }
            .navigationTitle("طلباتي")
        }
    }
}

struct ReadOrdersView_Previews: PreviewProvider {
    static var previews: some View {
        ReadOrdersView()
    }
}
