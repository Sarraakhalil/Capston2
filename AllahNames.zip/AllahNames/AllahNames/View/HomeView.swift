//
//  HomeView.swift
//  AllahNames
//
//  Created by سرّاء. on 19/07/1444 AH.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        TabView {
            ZStack{
                VStack{
                    Image("homebg4")
                        .resizable()
                        .frame(width: 400, height: 400)
                        .padding(.bottom, 330)
                        .ignoresSafeArea()
                }
                Spacer()
             
                  //  Spacer()
                    VStack{
                        HStack{
                            NavigationLink(destination: {NameAPIView()}) {
                                Text("معاني \n الأسماء")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.black)
                                    .frame(width: 150, height: 180)
                                  //  .background(.white.opacity(0.9))
                                    .background(Color.white.opacity(0.9))
                                    .cornerRadius(16)
                                    .shadow(radius: 16)
                            }.padding(.bottom, -20)
                                .padding(.bottom, 20)
//                            .padding(.bottom, -220)

                            NavigationLink(destination: {BooksView()}) {
                                Text("عرض \n الكتب")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.black)
                                    .frame(width: 150, height: 180)
                                 //   .background(.white.opacity(0.9))
                                    .background(Color.white.opacity(0.9))
                                    .cornerRadius(16)
                                    .shadow(radius: 16)
                            }.padding(.bottom, -60)
                                .padding(.leading)
                               

                  
                        }
                        HStack{
                            NavigationLink(destination: {NoteView()}) {
                                Text("إضافة \n فائدة")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.black)
                                    .frame(width: 150, height: 180)
                                  //  .background(.white.opacity(0.9))
                                    .background(Color.white.opacity(0.9))
                                    .cornerRadius(16)
                                    .shadow(radius: 16)
                            } .padding(.top, 20)
                            
                            NavigationLink(destination: {}) {
                                Text(" مواقع \n المكتبات")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.black)
                                    .frame(width: 150, height: 180)
                                    .background(Color.white.opacity(0.9))
                                    .cornerRadius(16)
                                    .shadow(radius: 16)
                            }.padding(.bottom, -80)
                                .padding(.leading)
                  
                        }.padding(.bottom, -300)
                        
                        
                    }
                        .frame(width: 400, height: 200)
                        .background(Color.white)
            }
            
            .tabItem {
                Image(systemName: "house.fill")
            }
            
            LocationView()
                .tabItem {
                    Image(systemName: "location.square.fill")
                }
            
            ProfileView()
                .tabItem {
                    Image(systemName: "person")
                }
        }
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            HomeView()
        }
        .environmentObject(ListViewModel())
    }
}
